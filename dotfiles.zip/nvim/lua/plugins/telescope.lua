return {
  "nvim-telescope/telescope.nvim",
  keys = {
    {
      "<leader>sb",
      function()
        require("telescope.builtin").current_buffer_fuzzy_find(require("telescope.themes").get_dropdown({}))
      end,
      desc = "Buffer",
    },
  },
}
