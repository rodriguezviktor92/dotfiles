return {
  "nvim-telescope/telescope-live-grep-args.nvim",
  keys = {
    {
      "<leader>fg",
      ":lua require('telescope').extensions.live_grep_args.live_grep_args()<cr>",
      desc = "Live GRep Args",
    },
  },
  config = function()
    require("telescope").load_extension("live_grep_args")
  end,
}
